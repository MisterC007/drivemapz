﻿export { supabaseBrowser } from "@/app/lib/supabase/browser";
